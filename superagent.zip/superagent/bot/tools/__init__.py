"""All SuperAgent tools — callable from the AI core."""
import httpx
import qrcode
import io
import base64
import asyncio
import subprocess
import tempfile
import os
from bs4 import BeautifulSoup
import feedparser
from deep_translator import GoogleTranslator


async def web_search(query: str) -> str:
    """Search the web via DuckDuckGo Instant Answer."""
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get("https://api.duckduckgo.com/", params={
            "q": query, "format": "json", "no_html": 1, "skip_disambig": 1,
        })
        data = r.json()
        out = []
        if data.get("AbstractText"):
            out.append(data["AbstractText"])
        for t in data.get("RelatedTopics", [])[:5]:
            if isinstance(t, dict) and t.get("Text"):
                out.append(f"- {t['Text']}")
        return "\n".join(out) or "No results found."


async def fetch_url(url: str) -> str:
    """Fetch a webpage and return cleaned text content."""
    async with httpx.AsyncClient(timeout=20, follow_redirects=True) as c:
        r = await c.get(url, headers={"User-Agent": "Mozilla/5.0 SuperAgent"})
        soup = BeautifulSoup(r.text, "html.parser")
        for tag in soup(["script", "style", "nav", "footer"]):
            tag.decompose()
        text = " ".join(soup.get_text().split())
        return text[:4000]


async def get_weather(location: str) -> str:
    """Current weather via Open-Meteo (no API key needed)."""
    async with httpx.AsyncClient(timeout=15) as c:
        geo = await c.get("https://geocoding-api.open-meteo.com/v1/search",
                          params={"name": location, "count": 1})
        gdata = geo.json()
        if not gdata.get("results"):
            return f"Location '{location}' not found."
        loc = gdata["results"][0]
        lat, lon = loc["latitude"], loc["longitude"]
        w = await c.get("https://api.open-meteo.com/v1/forecast", params={
            "latitude": lat, "longitude": lon,
            "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code",
            "timezone": "auto",
        })
        wd = w.json()["current"]
        return (f"📍 {loc['name']}, {loc.get('country','')}\n"
                f"🌡️ Temperature: {wd['temperature_2m']}°C\n"
                f"💧 Humidity: {wd['relative_humidity_2m']}%\n"
                f"💨 Wind: {wd['wind_speed_10m']} km/h")


async def crypto_price(coin: str) -> str:
    """Cryptocurrency price via CoinGecko."""
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get("https://api.coingecko.com/api/v3/simple/price", params={
            "ids": coin.lower(), "vs_currencies": "usd,eur",
            "include_24hr_change": "true",
        })
        data = r.json()
        if not data:
            return f"Coin '{coin}' not found. Try 'bitcoin', 'ethereum', etc."
        out = []
        for cid, p in data.items():
            change = p.get("usd_24h_change", 0)
            arrow = "📈" if change >= 0 else "📉"
            out.append(f"💰 {cid.upper()}: ${p.get('usd', '?')} | €{p.get('eur', '?')} {arrow} {change:.2f}%")
        return "\n".join(out)


async def translate(text: str, target: str = "en") -> str:
    """Translate text to a target language."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None, lambda: GoogleTranslator(source="auto", target=target).translate(text))


def generate_qr(data: str) -> bytes:
    """Generate a QR code PNG (returns raw bytes)."""
    img = qrcode.make(data)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


async def read_rss(url: str) -> str:
    """Parse an RSS feed and return recent entries."""
    loop = asyncio.get_event_loop()
    feed = await loop.run_in_executor(None, feedparser.parse, url)
    if not feed.entries:
        return "No entries found."
    out = [f"📰 {feed.feed.get('title', 'RSS Feed')}\n"]
    for e in feed.entries[:5]:
        out.append(f"• {e.get('title', 'No title')}\n  {e.get('link', '')}")
    return "\n".join(out)


async def video_info(url: str) -> str:
    """Extract info from any video URL via yt-dlp."""
    loop = asyncio.get_event_loop()
    def _extract():
        import yt_dlp
        with yt_dlp.YoutubeDL({"quiet": True, "skip_download": True}) as ydl:
            info = ydl.extract_info(url, download=False)
            return {
                "title": info.get("title"),
                "uploader": info.get("uploader"),
                "duration": info.get("duration"),
                "view_count": info.get("view_count"),
                "thumbnail": info.get("thumbnail"),
                "description": (info.get("description") or "")[:500],
            }
    info = await loop.run_in_executor(None, _extract)
    dur = info["duration"]
    dur_str = f"{dur // 60}:{dur % 60:02d}" if dur else "?"
    return (f"🎬 {info['title']}\n"
            f"👤 {info['uploader']}\n"
            f"⏱️ {dur_str} | 👁️ {info.get('view_count','?')} views\n\n"
            f"{info['description']}")


async def run_python(code: str) -> str:
    """Run Python code in an isolated subprocess (10s timeout)."""
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as f:
        f.write(code)
        path = f.name
    try:
        proc = await asyncio.create_subprocess_exec(
            "python", path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
        except asyncio.TimeoutError:
            proc.kill()
            return "⏱️ Timeout (10s)"
        out = stdout.decode("utf-8", errors="replace")
        err = stderr.decode("utf-8", errors="replace")
        result = ""
        if out:
            result += f"📤 Output:\n{out[:2000]}"
        if err:
            result += f"\n❌ Error:\n{err[:1000]}"
        return result or "✅ (no output)"
    finally:
        os.unlink(path)
