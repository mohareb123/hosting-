"""FastAPI dashboard for SuperAgent."""
import secrets
from datetime import datetime
from fastapi import FastAPI, Request, Form, Depends, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import uvicorn

import storage
from config import DASHBOARD_SECRET, DASHBOARD_PORT

app = FastAPI(title="SuperAgent Dashboard")
templates = Jinja2Templates(directory="dashboard/templates")
app.mount("/static", StaticFiles(directory="dashboard/static"), name="static")
security = HTTPBasic()


def fmt_time(ts):
    if not ts: return "-"
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


templates.env.filters["fmt_time"] = fmt_time


def auth(creds: HTTPBasicCredentials = Depends(security)):
    ok_user = secrets.compare_digest(creds.username, "admin")
    ok_pass = secrets.compare_digest(creds.password, DASHBOARD_SECRET)
    if not (ok_user and ok_pass):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized",
            headers={"WWW-Authenticate": "Basic"},
        )
    return creds.username


@app.on_event("startup")
async def on_start():
    await storage.init_db()


@app.get("/", response_class=HTMLResponse)
async def home(request: Request, user: str = Depends(auth)):
    stats = await storage.get_stats()
    return templates.TemplateResponse("dashboard.html", {
        "request": request, "stats": stats, "page": "home",
    })


@app.get("/users", response_class=HTMLResponse)
async def users_page(request: Request, user: str = Depends(auth)):
    users = await storage.list_users(200)
    return templates.TemplateResponse("users.html", {
        "request": request, "users": users, "page": "users",
    })


@app.post("/users/{user_id}/block")
async def block_user(user_id: int, blocked: int = Form(...), user: str = Depends(auth)):
    await storage.set_blocked(user_id, bool(blocked))
    return RedirectResponse("/users", status_code=303)


@app.get("/messages", response_class=HTMLResponse)
async def msgs(request: Request, user: str = Depends(auth)):
    msgs = await storage.recent_messages(100)
    return templates.TemplateResponse("messages.html", {
        "request": request, "messages": msgs, "page": "messages",
    })


def main():
    uvicorn.run("dashboard.main:app", host="0.0.0.0",
                port=DASHBOARD_PORT, reload=False)


if __name__ == "__main__":
    main()
